<footer>
    <hr>
    <p class="text-center">Gestion d'absence - Simplon - 2020 </p>
</footer>
<script src="./js/jquery-3.2.1.min.js" ></script>
<script src="./js/bootstrap.min.js" ></script>
<script src="./js/app.js" ></script>
</body>
</html>
<?php if(isset($_SESSION["message"])) unset($_SESSION["message"]); ?>