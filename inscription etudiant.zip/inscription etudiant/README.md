[Language : French]

# Gestion d’Absence (GAbs)
*GAbs* est une application web en PHP pour la gestion d’absence ([Demo](https://www.youtube.com/watch?v=qnqLmo-b208)).

## Technologies et Frameworks utilisées:
* [CodeIgniter](https://codeigniter.com/) (Architecture MVC)
* [Bootstrap](https://getbootstrap.com/)
* Language [PHP](http://php.net/)
* Librairie [PHPExcel](https://github.com/PHPOffice/PHPExcel) (`PHPExcel` est obsolète, il est remplacé par `PhpSpreadsheet`)